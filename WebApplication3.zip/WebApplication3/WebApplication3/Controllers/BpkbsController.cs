﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Model;

namespace WebApplication3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BpkbsController : ControllerBase
    {
        private readonly BPKBContext _context;

        public BpkbsController(BPKBContext context)
        {
            _context = context;
        }

        // GET: api/Bpkbs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Bpkb>>> GetBPKBList()
        {
            return await _context.BPKBList.ToListAsync();
        }

        // GET: api/Bpkbs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Bpkb>> GetBpkb(string id)
        {
            var bpkb = await _context.BPKBList.FindAsync(id);

            if (bpkb == null)
            {
                return NotFound();
            }

            return bpkb;
        }

        // PUT: api/Bpkbs/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBpkb(string id, Bpkb bpkb)
        {
            if (id != bpkb.aggrement_Number)
            {
                return BadRequest();
            }

            _context.Entry(bpkb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BpkbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Bpkbs
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Bpkb>> PostBpkb(Bpkb bpkb)
        {
            _context.BPKBList.Add(bpkb);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (BpkbExists(bpkb.aggrement_Number))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetBpkb", new { id = bpkb.aggrement_Number }, bpkb);
        }

        // DELETE: api/Bpkbs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Bpkb>> DeleteBpkb(string id)
        {
            var bpkb = await _context.BPKBList.FindAsync(id);
            if (bpkb == null)
            {
                return NotFound();
            }

            _context.BPKBList.Remove(bpkb);
            await _context.SaveChangesAsync();

            return bpkb;
        }

        private bool BpkbExists(string id)
        {
            return _context.BPKBList.Any(e => e.aggrement_Number == id);
        }
    }
}
