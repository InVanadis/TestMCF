﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3.Model
{
    public class storage_location
    {
        public string location_id { get; set; }
        public string location_name { get; set; }
    }
}
