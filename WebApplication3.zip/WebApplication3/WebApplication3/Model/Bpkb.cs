﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3.Model
{
    public class Bpkb
    {
        [Key]
        public string aggrement_Number { get; set; }
        public string bpkb_no { get; set; }
        public string branch_id { get; set; }
        public DateTime bpkb_date { get; set; }
        public string faktur_no { get; set; }
        public string faktur_date { get; set; }
        public string location_id { get; set; }
        public string polico_no { get; set; }
        public DateTime bpkp_date_in { get; set; }
        public string create_by { get; set; }
        public DateTime created_om { get; set; }
        public string last_updated_by { get; set; }
        public DateTime last_updated_date { get; set; }
    }
}
