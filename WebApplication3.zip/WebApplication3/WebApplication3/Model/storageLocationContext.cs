﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication3.Model
{
    public class storageLocationContext :DbContext
    {
        public storageLocationContext(DbContextOptions<storageLocationContext> options) : base(options)
        {

        }
        public DbSet<storage_location> BPKBList { get; set; } = null;
    }
}
