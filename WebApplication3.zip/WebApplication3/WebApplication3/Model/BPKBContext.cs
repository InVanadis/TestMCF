﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace WebApplication3.Model
{
    public class BPKBContext: DbContext
    {
        public BPKBContext(DbContextOptions<BPKBContext> options) : base(options)
        {

        }
        public DbSet<Bpkb> BPKBList { get; set; } = null;
    }
}
